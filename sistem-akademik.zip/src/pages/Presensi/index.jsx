import PresensiTemp from "@components/Templates/PresensiTemp";

const Presensi = () => {
  return (
    <div>
      <PresensiTemp />
    </div>
  );
};

export default Presensi;
