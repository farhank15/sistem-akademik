import React from "react";
import Doodle from "@assets/images/doodle.png";

const CardPresensi = ({ text }) => {
  return (
    <div
      className="relative flex items-center w-full h-32 p-4 overflow-hidden rounded-lg shadow-lg bg-accent-light"
      style={{
        backgroundImage: `url(${Doodle})`,
        backgroundSize: "cover",
        backgroundPosition: "right",
        backgroundRepeat: "no-repeat",
      }}
    >
      <div className="flex flex-col px-5 text-white">
        <h1 className="z-10 text-2xl font-bold md:text-5xl">{text}</h1>
      </div>
      <div className="absolute inset-0 bg-black opacity-50"></div>
    </div>
  );
};

export default CardPresensi;
