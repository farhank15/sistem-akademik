const Card = ({ children, className }) => {
  return (
    <div
      className={`rounded-lg shadow-lg text-neutral-light shadow-primary-dark bg-primary ${className}`}
    >
      {children}
    </div>
  );
};

export default Card;
