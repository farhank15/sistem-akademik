import ProfileMol from "@components/molecules/ProfileMol";

const ProfileTemp = () => {
  return (
    <div className="my-5">
      <ProfileMol />
    </div>
  );
};

export default ProfileTemp;
