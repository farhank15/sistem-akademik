import PresensiDosen from "@components/molecules/JadwalKuliahDosen";
import PresensiMahasiswa from "@components/molecules/PresensiMahasiswa";

const PresensiTemp = () => {
  return (
    <div className="py-5">
      <PresensiMahasiswa />
      <PresensiDosen />
    </div>
  );
};

export default PresensiTemp;
