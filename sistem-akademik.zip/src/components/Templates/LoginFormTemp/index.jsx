import LoginFormMol from "@components/molecules/LoginFormMol";

const LoginFormTemp = () => {
  return (
    <div>
      <LoginFormMol />
    </div>
  );
};

export default LoginFormTemp;
