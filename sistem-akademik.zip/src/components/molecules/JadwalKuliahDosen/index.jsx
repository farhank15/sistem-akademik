import CardPresensi from "@components/atoms/CardPresensi";
import { useState } from "react";
import { FaEdit, FaSave, FaTimes, FaQrcode } from "react-icons/fa";
import QRCode from "react-qr-code";

const PresensiDosen = ({ initialClasses, onUpdate }) => {
  const [classes, setClasses] = useState(initialClasses);
  const [editIndex, setEditIndex] = useState(null);
  const [tempClass, setTempClass] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [currentQris, setCurrentQris] = useState(null);

  const startEdit = (index) => {
    setEditIndex(index);
    setTempClass({ ...classes[index] });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTempClass((prev) => ({ ...prev, [name]: value }));
  };

  const saveEdit = () => {
    const newClasses = [...classes];
    newClasses[editIndex] = tempClass;
    setClasses(newClasses);
    setEditIndex(null);
    setTempClass(null);
    onUpdate(newClasses);
  };

  const cancelEdit = () => {
    setEditIndex(null);
    setTempClass(null);
  };

  const handleQrisClick = (qrisData) => {
    setCurrentQris(qrisData);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setCurrentQris(null);
  };

  return (
    <div
      className="flex flex-col items-center justify-center min-h-screen"
      style={{ userSelect: "none" }}
    >
      <CardPresensi text="Jadwal Kuliah Dosen" icon={<FaQrcode />} />
      <div className="w-full p-2 rounded-lg shadow-md max-w-7xl">
        <div className="overflow-x-auto">
          <table className="table w-[80rem]">
            <thead>
              <tr className="text-white bg-accent">
                <th className="w-1/10 md:w-1/12">Aksi</th>
                <th className="w-1/10 md:w-1/12">Hari</th>
                <th className="w-3/20 md:w-3/20 whitespace-nowrap">Jam</th>
                <th className="w-2/5 md:w-2/5 whitespace-nowrap">Matakuliah</th>
                <th className="w-1/10 md:w-1/12">Kode</th>
                <th className="w-1/20 md:w-1/24">SKS</th>
                <th className="w-1/10 md:w-1/12">SMT</th>
                <th className="w-1/5 md:w-1/5">Dosen</th>
                <th className="w-1/20 md:w-1/24 whitespace-nowrap">Ruang</th>
                <th className="w-1/10 md:w-1/12">QRIS</th>
              </tr>
            </thead>
            <tbody>
              {classes.map((item, index) => (
                <tr
                  key={index}
                  className="transition duration-300 hover:bg-neutral-dark"
                >
                  <td className="w-1/10 md:w-1/12">
                    {editIndex === index ? (
                      <div className="flex space-x-2">
                        <button
                          onClick={saveEdit}
                          className="text-xl text-green-500"
                        >
                          <FaSave />
                        </button>
                        <button
                          onClick={cancelEdit}
                          className="text-xl text-red-500"
                        >
                          <FaTimes />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => startEdit(index)}
                        className="text-xl text-blue-500"
                      >
                        <FaEdit />
                      </button>
                    )}
                  </td>
                  <td className="w-1/10 md:w-1/12">
                    {editIndex === index ? (
                      <input
                        type="text"
                        name="day"
                        value={tempClass.day}
                        onChange={handleChange}
                        className="input input-bordered"
                      />
                    ) : (
                      item.day
                    )}
                  </td>
                  <td className="w-3/20 md:w-3/20 whitespace-nowrap">
                    {editIndex === index ? (
                      <input
                        type="text"
                        name="time"
                        value={tempClass.time}
                        onChange={handleChange}
                        className="input input-bordered"
                      />
                    ) : (
                      item.time
                    )}
                  </td>
                  <td className="w-2/5 md:w-2/5 whitespace-nowrap">
                    {item.course}
                  </td>
                  <td className="w-1/10 md:w-1/12">{item.code}</td>
                  <td className="w-1/20 md:w-1/24">{item.sks}</td>
                  <td className="w-1/10 md:w-1/12">{item.semester}</td>
                  <td className="w-1/5 md:w-1/5">{item.instructor}</td>
                  <td className="w-1/20 md:w-1/24 whitespace-nowrap">
                    {editIndex === index ? (
                      <input
                        type="text"
                        name="room"
                        value={tempClass.room}
                        onChange={handleChange}
                        className="input input-bordered"
                      />
                    ) : (
                      item.room
                    )}
                  </td>
                  <td className="w-1/10 md:w-1/12">
                    <button onClick={() => handleQrisClick(item.qrisData)}>
                      <FaQrcode className="text-xl text-blue-500" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75">
          <div className="relative flex flex-col items-center p-4 bg-white rounded-lg w-72 lg:w-72">
            <QRCode value={currentQris} size={256} />
            <button
              onClick={closeModal}
              className="p-2 mt-4 text-white bg-red-500 rounded"
            >
              <FaTimes />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const App = () => {
  const initialClasses = [
    {
      day: "Senin",
      time: "10:15 s/d 12:45",
      course: "Kerja Praktek",
      code: "TINKFM6023",
      sks: 3,
      semester: "Genap",
      instructor: "Dr. Ir. Budi Santoso",
      room: "Ruang 101",
      qrisData: "https://example.com/qris/1",
    },
    {
      day: "Selasa",
      time: "13:00 s/d 15:30",
      course: "Arsitektur Enterprise",
      code: "TINKFM6013",
      sks: 3,
      semester: "Genap",
      instructor: "Dr. Ir. Budi Santoso",
      room: "Ruang 202",
      qrisData: "https://example.com/qris/2",
    },
    {
      day: "Rabu",
      time: "07:30 s/d 10:00",
      course: "Kriptografi",
      code: "TINKFM6043",
      sks: 3,
      semester: "Genap",
      instructor: "Dr. Ir. Budi Santoso",
      room: "Ruang 203",
      qrisData: "https://example.com/qris/3",
    },
    // Data jadwal lainnya
  ];

  const [classes, setClasses] = useState(initialClasses);

  const updateClasses = (updatedClasses) => {
    setClasses(updatedClasses);
  };

  return (
    <div>
      <PresensiDosen initialClasses={classes} onUpdate={updateClasses} />
    </div>
  );
};

export default App;
