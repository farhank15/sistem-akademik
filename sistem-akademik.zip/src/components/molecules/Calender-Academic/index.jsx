import React, { useState } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";

// Data sampel untuk acara
const events = [
  { date: new Date(2024, 6, 5), title: "Mulai Semester" },
  { date: new Date(2024, 6, 20), title: "Hari Kemerdekaan" },
  { date: new Date(2024, 7, 15), title: "Ujian Tengah Semester" },
  { date: new Date(2024, 11, 25), title: "Liburan Natal" },
  { date: new Date(2024, 11, 25), title: "Liburan Natal" },
  { date: new Date(2024, 11, 25), title: "Liburan Natal" },
  { date: new Date(2024, 11, 25), title: "Liburan Natal" },
  { date: new Date(2024, 11, 25), title: "Liburan Natal" },
];

const CalendarAcademic = () => {
  const renderTileContent = ({ date, view }) => {
    if (view === "month") {
      const event = events.find(
        (event) => event.date.toDateString() === date.toDateString()
      );
      return event ? (
        <div className="relative w-full h-full group">
          <div className="w-full h-full bg-yellow-300 rounded-full"></div>
          <div className="absolute z-10 hidden p-2 bg-white border border-gray-300 rounded-lg shadow-lg left-10 group-hover:block">
            <h4 className="font-semibold text-md">{event.title}</h4>
            <p className="text-sm">{event.date.toDateString()}</p>
          </div>
        </div>
      ) : null;
    }
  };

  return (
    <div className="flex flex-col p-4 mx-auto bg-white h-auto rounded-lg shadow-lg md:h-[40rem] lg:flex-row text-primary">
      <div className="w-full mb-4 lg:w-3/4 lg:pr-4 lg:mb-0">
        <h2 className="mb-4 text-2xl font-semibold text-center lg:text-4xl">
          Kalender Akademik
        </h2>
        <p className="mb-6 text-lg text-center lg:text-xl">
          - Semester Genap 2023/2024 -
        </p>
        <Calendar
          onChange={() => {}}
          value={new Date()}
          tileContent={renderTileContent}
          className="p-3 m-auto text-lg text-center border-0 lg:w-full"
        />
      </div>
      <div
        className="w-full p-4 overflow-y-auto bg-gray-100 rounded-lg lg:w-1/4"
        style={{ maxHeight: "600px" }}
      >
        <h3 className="mb-4 text-xl font-semibold text-center">Jadwal</h3>
        <ul>
          {events.map((event, index) => (
            <li key={index} className="mb-4">
              <div className="p-4 bg-white rounded-lg shadow-md">
                <h4 className="text-lg font-semibold">{event.title}</h4>
                <p className="text-md">{event.date.toDateString()}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default CalendarAcademic;
