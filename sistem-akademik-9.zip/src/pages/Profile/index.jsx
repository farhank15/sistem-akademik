import ProfileTemp from "@components/Templates/ProfileTemp";

const Profile = () => {
  return (
    <div>
      <ProfileTemp />
    </div>
  );
};

export default Profile;
