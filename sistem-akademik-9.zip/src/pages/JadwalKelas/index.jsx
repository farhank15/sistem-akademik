import JadwalKelasTemp from "@components/Templates/JadwalKelasTemp";

const JadwalKelas = () => {
  return (
    <div>
      <JadwalKelasTemp />
    </div>
  );
};

export default JadwalKelas;
